var arr=["sport","asdu","koiko","amar","gg7uhuyu","isfuyguyg"];
var arrr=0;
for (var i=0;i<arr.length; i++) {
	if(i+=arrr){
       arrr++
	}
}
console.log(i)
////////////////////////////////
// var a=1;
// function f1 (y){
// 	for (var i=1; i<=y; i++) {
// 		console.log(a*i);
// 		a*=i;
// 	}
// }
// f1(5)
////////////////////////////
 var arr2=[1,2,2,3,4,4];
 var z=0;
 for (var i=0;i<arr2.length;i++) {
 	if (i==arr2[i]){
 		z++
 	}
 }
	 // console.log(z);